import tensorflow as tf


class MinClipSchedule(tf.keras.optimizers.schedules.LearningRateSchedule):
    """在基础学习率调度上增加最小学习率下限"""
    def __init__(self, base_schedule, min_lr=1e-6):
        super().__init__()
        self.base_schedule = base_schedule
        self.min_lr = tf.cast(min_lr, tf.float32)

    def __call__(self, step):
        lr = self.base_schedule(step)
        return tf.maximum(lr, self.min_lr)

    def get_config(self):
        return {
            "base_schedule": tf.keras.optimizers.schedules.serialize(self.base_schedule),
            "min_lr": float(self.min_lr.numpy()),
        }

    @classmethod
    def from_config(cls, config):
        config["base_schedule"] = tf.keras.optimizers.schedules.deserialize(config["base_schedule"])
        return cls(**config)


class DQNModel:
    def __init__(self):
        self.learning_rate = 0.01
        self.learning_rate_minimum = 0.0005
        self.learning_rate_decay = 0.96
        self.learning_rate_decay_step = 500000
        self.initialize_network()
        self.compile_model()
        # 由 Agent 注入
        self.tb_writer = None

    def initialize_network(self):
        self.model = self.build_dqn()
        self.target_model = self.build_dqn()

    def build_dqn(self):
        n_input = 102
        n_output = 60

        model = tf.keras.Sequential([
            tf.keras.layers.InputLayer(input_shape=(n_input,)),
            tf.keras.layers.Dense(
                700, activation='relu',
                kernel_initializer=tf.keras.initializers.TruncatedNormal(stddev=0.1)
            ),
            tf.keras.layers.Dense(
                350, activation='relu',
                kernel_initializer=tf.keras.initializers.TruncatedNormal(stddev=0.1)
            ),
            tf.keras.layers.Dense(
                180, activation='relu',
                kernel_initializer=tf.keras.initializers.TruncatedNormal(stddev=0.1)
            ),
            tf.keras.layers.Dense(
                n_output, activation='relu',
                kernel_initializer=tf.keras.initializers.TruncatedNormal(stddev=0.1)
            )
        ])

        return model

    def forward(self, inputs):
        inputs = tf.reshape(inputs, [-1, 102])
        return self.model(inputs, training=True)

    def forward_target(self, inputs):
        return self.target_model(inputs, training=False)

    def update_target_network(self):
        self.target_model.set_weights(self.model.get_weights())

    def clipped_error(self, x):
        return tf.where(tf.abs(x) < 1.0, 0.5 * tf.square(x), tf.abs(x) - 0.5)

    def compile_model(self):
        # 基础学习率衰减（交由优化器在训练步中调用）
        base_lr_schedule = tf.keras.optimizers.schedules.ExponentialDecay(
            initial_learning_rate=self.learning_rate,
            decay_steps=self.learning_rate_decay_step,
            decay_rate=self.learning_rate_decay,
            staircase=True
        )
        # 叠加最小学习率下限
        lr_schedule = MinClipSchedule(base_lr_schedule, min_lr=self.learning_rate_minimum)

        # 把 Schedule 直接传给优化器（不要用函数闭包依赖 optimizer.iterations）
        optimizer = tf.keras.optimizers.RMSprop(
            learning_rate=lr_schedule,
            rho=0.95,
            epsilon=0.01
        )

        self.model.compile(optimizer=optimizer, loss='mean_squared_error')
        # 如需加载已有权重，取消下一行注释
        # self.model.load_weights('weight/dqn_weights.h5')

    def current_lr(self) -> float:
        """健壮地获取当前学习率"""
        opt = self.model.optimizer
        lr = opt.learning_rate
        if isinstance(lr, tf.keras.optimizers.schedules.LearningRateSchedule):
            return float(lr(opt.iterations).numpy())
        try:
            return float(tf.convert_to_tensor(lr).numpy())
        except Exception:
            lr_attr = getattr(opt, 'lr', lr)
            return float(tf.convert_to_tensor(lr_attr).numpy())

    @tf.function
    def train_step(self, inputs, targets, actions):
        with tf.GradientTape() as tape:
            q_values = self.forward(inputs)
            num_actions = tf.shape(q_values)[1]
            action_masks = tf.one_hot(tf.cast(actions, tf.int32), num_actions)
            q_acted = tf.reduce_sum(q_values * action_masks, axis=1)
            loss = tf.reduce_mean(tf.square(targets - q_acted))

        grads = tape.gradient(loss, self.model.trainable_variables)
        self.model.optimizer.apply_gradients(zip(grads, self.model.trainable_variables))
        return loss, q_values