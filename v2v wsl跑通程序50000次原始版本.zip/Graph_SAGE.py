import networkx as nx
from Environment import *
import tensorflow as tf
from model_Graph import GraphModel
import re
import matplotlib.pyplot as plt
import os
import tensorflow.keras as keras
import numpy as np  # 补充缺失的导入

# 自定义一个带最小学习率下限的学习率调度器
class MinClipSchedule(tf.keras.optimizers.schedules.LearningRateSchedule):
    """
    在基础学习率调度上加一个最小学习率下限
    """
    def __init__(self, base_schedule, min_lr=1e-6):
        super().__init__()
        self.base_schedule = base_schedule
        self.min_lr = tf.cast(min_lr, tf.float32)

    def __call__(self, step):
        lr = self.base_schedule(step)
        return tf.maximum(lr, self.min_lr)

    def get_config(self):
        return {
            "base_schedule": tf.keras.optimizers.schedules.serialize(self.base_schedule),
            "min_lr": float(self.min_lr.numpy()),
        }

    @classmethod
    def from_config(cls, config):
        config["base_schedule"] = tf.keras.optimizers.schedules.deserialize(config["base_schedule"])
        return cls(**config)


class GraphSAGE_sup(keras.Model):
    def __init__(self, environment):
        super().__init__()
        self.env = environment
        self.weight_dir = 'weight'
        self.G_model = GraphModel(sample_num=5, depth=2, dims=20, gcn=True, concat=True)
        self.G_model_target = GraphModel(sample_num=5, depth=2, dims=20, gcn=True, concat=True)
        self.dims = self.G_model.dims
        self.num_vehicle = len(self.env.vehicles)
        self.s_neighs = []
        self.s1_neighs = []
        self.s2_neighs = []
        # 避免与 keras.Model 的属性混淆
        self.loss_history = []
        self.saver = None
        self.features = np.zeros((3*self.num_vehicle, 60))
        self.learning_rate = 0.01
        self.learning_rate_minimum = 0.0001
        self.learning_rate_decay = 0.96
        self.learning_rate_decay_step = 1000000
        self.compile_model()
        self.num_V2V_list = np.zeros((len(self.env.vehicles), len(self.env.vehicles)))
        self.link = np.zeros((3*self.num_vehicle, 2))

        # TensorBoard：由 Agent 注入（Agent 会赋值）
        self.tb_writer = None

    def update_target_network(self):
        self.G_model_target.set_weights(self.G_model.get_weights())

    def compile_model(self):
        # 1) 基础学习率衰减（让 Optimizer 自己用 iterations 调用）
        base_lr_schedule = tf.keras.optimizers.schedules.ExponentialDecay(
            initial_learning_rate=self.learning_rate,
            decay_steps=self.learning_rate_decay_step,
            decay_rate=self.learning_rate_decay,
            staircase=True
        )
        # 2) 加一个最小学习率下限
        lr_schedule = MinClipSchedule(base_lr_schedule, min_lr=self.learning_rate_minimum)

        # 3) 直接把 Schedule 传给优化器（不要用闭包访问 optimizer.iterations）
        optimizer = tf.keras.optimizers.RMSprop(
            learning_rate=lr_schedule,
            rho=0.95,
            epsilon=0.01
        )
        self.G_model.compile(optimizer=optimizer, loss='mean_squared_error')

    def _current_lr(self) -> float:
        """
        健壮地获取当前学习率：
        - 如果是 LearningRateSchedule：调用 schedule(iterations)
        - 否则当作 Variable/Tensor 取值
        """
        opt = self.G_model.optimizer
        lr = opt.learning_rate
        if isinstance(lr, tf.keras.optimizers.schedules.LearningRateSchedule):
            return float(lr(opt.iterations).numpy())
        try:
            return float(tf.convert_to_tensor(lr).numpy())
        except Exception:
            # 兜底（某些老版本优化器用 lr 属性）
            lr_attr = getattr(opt, 'lr', lr)
            return float(tf.convert_to_tensor(lr_attr).numpy())

    def build_graph(self, num_V2V_list):
        G = nx.Graph()  # 无向图
        added_nodes_order = []
        n = np.max(self.env.Distance)
        # 添加节点
        for i in range(len(self.env.vehicles)):
            for j in range(3):
                if num_V2V_list[i, self.env.vehicles[i].destinations[j]] == 1:
                    label = f"{i} to {self.env.vehicles[i].destinations[j]}"
                    self.link[3*i+j, 0] = i
                    self.link[3*i+j, 1] = self.env.vehicles[i].destinations[j]
                    G.add_node(label, features=self.features[3*i+j, :])  # 使用label作为节点的键
                    added_nodes_order.append(label)
        self.link = self.link.astype(int)
        nodes_idx = []
        for m, node_label in enumerate(added_nodes_order):
            nodes_idx.append(m)

        # 构建图的结构
        for i in range(len(self.env.vehicles)):
            for j in range(3):
                node_label = f"{i} to {self.env.vehicles[i].destinations[j]}"
                pattern1 = re.compile(rf"\b{i}\b")
                pattern2 = re.compile(rf"\b{self.env.vehicles[i].destinations[j]}\b")
                if node_label in G:  # 检查节点是否存在于图中
                    filtered_labels1 = [label for label in G.nodes if pattern1.search(label)]
                    filtered_labels2 = [label for label in G.nodes if pattern2.search(label)]
                    for label in filtered_labels1:
                        if label != node_label:  # 排除自环
                            m_str, _ = label.split(" to ", 1)
                            m = int(m_str)
                            if m == i:
                                edge_weight = 1.0
                            else:
                                Distance1 = self.env.Distance[m, i]
                                edge_weight = (n - Distance1) / n
                            G.add_edge(node_label, label, weight=edge_weight)
                    for label in filtered_labels2:
                        if label != node_label:  # 排除自环
                            m_str, _ = label.split(" to ", 1)
                            m = int(m_str)
                            if m == i:
                                edge_weight = 1.0
                            else:
                                Distance2 = self.env.Distance[m, i]
                                edge_weight = (n - Distance2) / n
                            G.add_edge(node_label, label, weight=edge_weight)
        return G, added_nodes_order, nodes_idx

    def sample(self, all_nodes, nodes, idx):
        s_neighs = []
        s_neighs_idx = []
        s_weights = []
        for node_index in idx:
            node_label = all_nodes[node_index]  # 根据节点索引获取节点标签
            neighs = list(nx.neighbors(self.graph, node_label))  # 根据节点标签获取邻居
            weights = []
            for neighbor in neighs:
                edge_data = self.graph.get_edge_data(node_label, neighbor)
                weight = edge_data['weight'] if 'weight' in edge_data else None
                weights.append(weight)

            if self.G_model.sample_num > len(neighs):
                sampled_indices = np.random.choice(len(neighs), self.G_model.sample_num, replace=True)
                sampled_neighs = [neighs[i] for i in sampled_indices]
                sampled_weights = [weights[i] for i in sampled_indices]
            else:
                sampled_indices = np.random.choice(len(neighs), self.G_model.sample_num, replace=False)
                sampled_neighs = [neighs[i] for i in sampled_indices]
                sampled_weights = [weights[i] for i in sampled_indices]
            if self.G_model.gcn:
                sampled_neighs.append(node_label)
                sampled_weights.append(1.0)
            s_neighs.append(sampled_neighs)
            s_weights.append(sampled_weights)
            s_neighs_idx.append([all_nodes.index(neigh) for neigh in sampled_neighs])
        return s_neighs, s_neighs_idx, s_weights

    def fetch_batch(self, nodes, idx):
        self.s1_neighs = []
        self.s2_neighs = []
        self.s2_neighs_idx = []
        self.s2_weights = []
        s1_neighs, s1_neighs_idx, s1_weights = self.sample(nodes, nodes, idx)
        for neigh in s1_neighs_idx:
            s2_neighs, s2_neighs_idx, s2_weights = self.sample(nodes, s1_neighs, neigh)
            self.s2_neighs.append(s2_neighs)
            self.s2_neighs_idx.append(s2_neighs_idx)
            self.s2_weights.append(s2_weights)
        return s1_neighs_idx, self.s2_neighs_idx, s1_weights, self.s2_weights

    def load_graph(self, graph, order_nodes):
        self.graph = graph
        self.order_nodes = order_nodes

    def test_Complete(self, channel_reward, step, idx, train_flag=True):
        channel_reward = tf.convert_to_tensor(channel_reward, dtype=tf.float32)
        first_order_neighs = np.arange(3*self.num_vehicle)
        second_order_neighs = np.arange(3*self.num_vehicle)
        second_order_neighs = np.tile(second_order_neighs, (3*self.num_vehicle, 1))
        first_order_neighs = first_order_neighs.reshape(1, -1)
        second_order_neighs = second_order_neighs.reshape(1, 60, -1)
        inputs = (self.features, idx, first_order_neighs, second_order_neighs)
        agg_result = self.G_model.call_without_weights(inputs)
        agg_result = agg_result.numpy()
        print(agg_result)
        return agg_result

    def get_all_weights(self, node_indices, added_nodes_order):
        all_first_layer_weights = []
        all_second_layer_weights = []
        for node_index in node_indices:
            node_label = added_nodes_order[node_index]
            n = len(added_nodes_order)
            first_layer_weights = []
            second_layer_weights = []
        return all_first_layer_weights, all_second_layer_weights

    def test_get_neighs(self, idx):
        first_order_neighs, second_order_neighs, s1_weights, s2_weights = self.fetch_batch(self.order_nodes, idx)
        return first_order_neighs, second_order_neighs

    def test_unComplete(self, idx, first_order_neighs, second_order_neighs):
        inputs = (self.features, idx, first_order_neighs, second_order_neighs)
        agg_result = self.G_model.call_without_weights(inputs)
        agg_result = agg_result.numpy()
        return agg_result

    def get_edge_weights(self, idx, neighs):
        extracted_data = self.distance[idx, neighs]

    def use_GraphSAGE(self, channel_reward, step, idx, train_flag=True):
        channel_reward = tf.convert_to_tensor(channel_reward, dtype=tf.float32)
        first_order_neighs, second_order_neighs, s1_weights, s2_weights = self.fetch_batch(self.order_nodes, idx)
        inputs = (self.features, idx, first_order_neighs, second_order_neighs, s1_weights, s2_weights)

        if train_flag and step % 50 == 0 and step > 0:
            with tf.GradientTape() as G_tape:
                agg_result = self.G_model.call(inputs)
                agg_result_target = self.G_model_target(inputs)
                difference = agg_result - 0.5 * agg_result_target - 0.5 * channel_reward
                squared_difference = tf.square(difference)
                loss = tf.reduce_mean(squared_difference)
                grads = G_tape.gradient(loss, self.G_model.trainable_variables)
                self.G_model.optimizer.apply_gradients(zip(grads, self.G_model.trainable_variables))
                self.loss_history.append(loss.numpy())

                # TensorBoard: 记录 GNN 的 loss / lr / 输出统计
                if self.tb_writer is not None:
                    cur_lr = self._current_lr()
                    with self.tb_writer.as_default():
                        tf.summary.scalar('GNN/loss', loss, step=step)
                        tf.summary.scalar('GNN/lr', cur_lr, step=step)
                        tf.summary.scalar('GNN/agg_mean', tf.reduce_mean(agg_result), step=step)
        else:
            agg_result = self.G_model(inputs)

        if step % 100 == 99:
            self.update_target_network()
            self.G_model.save_weights('weight/GNN_weights.h5')

        agg_result = agg_result.numpy()
        return agg_result