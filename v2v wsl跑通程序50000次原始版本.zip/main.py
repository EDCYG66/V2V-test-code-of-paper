from __future__ import division, print_function
import os
import random
import argparse

# 在导入 TensorFlow 之前，确保 WSL 的 CUDA 用户态库对当前进程可见
if '/usr/lib/wsl/lib' not in os.environ.get('LD_LIBRARY_PATH', ''):
    os.environ['LD_LIBRARY_PATH'] = '/usr/lib/wsl/lib:' + os.environ.get('LD_LIBRARY_PATH', '')
# 建议：开启显存按需增长（也可以在 TF 配置里设置）
os.environ.setdefault('TF_FORCE_GPU_ALLOW_GROWTH', 'true')
# 如需强制仅用 CPU，可临时取消注释下一行
# os.environ['CUDA_VISIBLE_DEVICES'] = '-1'

# 命令行参数
parser = argparse.ArgumentParser()

# Model
parser.add_argument('--model', type=str, default='m1', help='Type of model')
parser.add_argument('--dueling', action='store_true', help='Whether to use dueling deep q-network')
parser.add_argument('--double_q', action='store_true', help='Whether to use double q-learning')

# Environment
parser.add_argument('--env_name', type=str, default='Breakout-v0', help='The name of gym environment to use')
parser.add_argument('--action_repeat', type=int, default=4, help='The number of action to be repeated')

# Etc
parser.add_argument('--use_gpu', action='store_true', help='Deprecated: GPU will be used if available; this flag now only controls extra prints')
parser.add_argument('--gpu_fraction', type=str, default='1/1', help='Deprecated: not used anymore')
parser.add_argument('--display', action='store_true', help='Whether to display the game screen or not')
parser.add_argument('--is_train', action='store_true', help='Whether to do training or testing')
parser.add_argument('--random_seed', type=int, default=123, help='Value of random seed')

FLAGS = parser.parse_args()

import tensorflow as tf
from Environment import Environ
from agent import Agent


def setup_gpu():
    """为所有可见 GPU 启用显存按需增长"""
    gpus = tf.config.list_physical_devices('GPU')
    if gpus:
        try:
            for g in gpus:
                tf.config.experimental.set_memory_growth(g, True)
            if FLAGS.use_gpu:
                print(f"Enabled memory growth for {len(gpus)} GPU(s).")
        except Exception as e:
            print("Set memory growth failed:", e)
    return gpus


def print_tf_info():
    """启动时打印一次关键信息，便于确认是否使用 GPU"""
    if FLAGS.use_gpu:
        try:
            info = tf.sysconfig.get_build_info()
            print("TF version:", tf.__version__)
            print("Built with CUDA?", info.get("is_cuda_build"))
            print("CUDA version:", info.get("cuda_version"))
            print("cuDNN version:", info.get("cudnn_version"))
        except Exception:
            pass
    print("Physical GPUs:", tf.config.list_physical_devices('GPU'))
    print("Logical GPUs:", tf.config.list_logical_devices('GPU'))


def main():
    # 随机种子
    tf.random.set_seed(FLAGS.random_seed)
    random.seed(FLAGS.random_seed)

    # GPU 初始化和信息打印
    setup_gpu()
    print_tf_info()

    # 构造环境
    up_lanes = [3.5 / 2, 3.5 / 2 + 3.5, 250 + 3.5 / 2, 250 + 3.5 + 3.5 / 2, 500 + 3.5 / 2, 500 + 3.5 + 3.5 / 2]
    down_lanes = [250 - 3.5 - 3.5 / 2, 250 - 3.5 / 2, 500 - 3.5 - 3.5 / 2, 500 - 3.5 / 2, 750 - 3.5 - 3.5 / 2,
                  750 - 3.5 / 2]
    left_lanes = [3.5 / 2, 3.5 / 2 + 3.5, 433 + 3.5 / 2, 433 + 3.5 + 3.5 / 2, 866 + 3.5 / 2, 866 + 3.5 + 3.5 / 2]
    right_lanes = [433 - 3.5 - 3.5 / 2, 433 - 3.5 / 2, 866 - 3.5 - 3.5 / 2, 866 - 3.5 / 2, 1299 - 3.5 - 3.5 / 2,
                   1299 - 3.5 / 2]
    width = 750
    height = 1299
    Env = Environ(down_lanes, up_lanes, left_lanes, right_lanes, width, height)
    Env.new_random_game()

    # 训练
    agent = Agent([], Env)
    agent.train()

    # 如需测试/可视化：
    # agent.play()
    # agent.play_complete_graph()
    # agent.play_un_complete_graph()


if __name__ == '__main__':
    main()